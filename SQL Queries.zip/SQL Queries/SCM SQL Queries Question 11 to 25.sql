use SCM ;

--Question 11 : Supplier-wise average lead_time_days, sorted ascending.

SELECT supplier_id , supplier_name ,AVG(lead_time_days) AS AvgLeadTime
FROM Suppliers
GROUP BY supplier_id , supplier_name
ORDER BY AvgLeadTime DESC


--Question 12 : Products not restocked in the last 60 days.

SELECT max(last_restocked_date)
FROM Inventory
-- Lattest date is 2025-12-03 , since we do not have exact will assume as we are in 2026 jan.

SELECT product_id ,last_restocked_date
FROM Inventory
where last_restocked_date < '2025-10-01' ;

--Question 13: Total quantity sold per product. 

SELECT p.product_id , p.product_name , SUM(oi.quantity) as TotalQuanatity
FROM Products p
INNER JOIN Order_Item oi
ON p.product_id = oi.product_id
GROUP BY P.product_id,P.product_name
ORDER BY TotalQuanatity DESC



--Question 14 : Find customers who placed more than 5 orders.

SELECT C.customer_id , C.first_name ,COUNT(O.customer_id) AS TotalCount
FROM Customers C
INNER JOIN Orders O
ON C.customer_id= O.customer_id
GROUP BY C.customer_id ,c.first_name
HAVING COUNT(O.customer_id)> 5 ;



--Question 15 : Which discount_rate range gives highest average profit_ratio?
-- Question 15: Which discount_rate range gives highest average profit_ratio?

SELECT 
    CASE 
        WHEN discount_rate = 0 THEN '0%'
        WHEN discount_rate <= 0.05 THEN '0-5%'
        WHEN discount_rate <= 0.10 THEN '5-10%'
        WHEN discount_rate <= 0.15 THEN '10-15%'
        WHEN discount_rate <= 0.20 THEN '15-20%'
        ELSE '20%+'
    END AS Discount_Range,
    AVG(profit_ratio) AS Avg_Profit_Ratio
FROM Order_Item
GROUP BY 
    CASE 
        WHEN discount_rate = 0 THEN '0%'
        WHEN discount_rate <= 0.05 THEN '0-5%'
        WHEN discount_rate <= 0.10 THEN '5-10%'
        WHEN discount_rate <= 0.15 THEN '10-15%'
        WHEN discount_rate <= 0.20 THEN '15-20%'
        ELSE '20%+'
    END
ORDER BY Avg_Profit_Ratio DESC;


-- Question 16 : List suppliers whose products have combined stock_quantity above a threshold (e.g. 500)

 SELECT P.product_id , P.product_name , SUM(I.stock_quantity) AS TQNT
 FROM Products P
 INNER JOIN Inventory I
 ON I.product_id = P.product_id
 GROUP BY P.product_id,P.product_name
 HAVING  SUM(I.stock_quantity) > 500;



 --Question 17 : Find the most frequently ordered product per category.



SELECT category_name, product_name, TotalCnt
FROM (
    SELECT 
        P.category_name, P.product_name,
        COUNT(oi.product_id) AS TotalCnt,
        ROW_NUMBER() OVER (PARTITION BY P.category_name ORDER BY COUNT(oi.product_id) DESC) AS rn
    FROM Order_Item oi
    INNER JOIN Products P
        ON P.product_id = oi.product_id
    GROUP BY P.category_name, P.product_name
) t
WHERE rn = 1
ORDER BY category_name;



-- Question 18 : Compare average unit_price vs average discount given, per category.


SELECT P.category_name, AVG(oi.unit_price) AS Avg_Unit_Price, AVG(oi.discount) AS Avg_Discount
FROM Order_Item oi
INNER JOIN Products P ON P.product_id = oi.product_id
GROUP BY P.category_name
ORDER BY Avg_Unit_Price DESC;


-- Question 19: Rank suppliers by lead_time_days within each country

SELECT supplier_id, supplier_name, country, lead_time_days, RANK() OVER (PARTITION BY country ORDER BY lead_time_days ASC) AS Lead_Time_Rank
FROM Suppliers
ORDER BY country, Lead_Time_Rank;


-- Question 20: Rank each product by total profit within its category

SELECT category_name, product_name, Total_Profit, RANK() OVER (PARTITION BY category_name ORDER BY Total_Profit DESC) AS Profit_Rank
FROM (
    SELECT P.category_name, P.product_name, SUM(oi.profit_per_order) AS Total_Profit
    FROM Order_Item oi
    INNER JOIN Products P ON P.product_id = oi.product_id
    GROUP BY P.category_name, P.product_name
) t
ORDER BY category_name, Profit_Rank;


-- Question 21: Running total of sales ordered by order_date

SELECT o.order_date, oi.sales, SUM(oi.sales) OVER (ORDER BY o.order_date) AS Running_Total_Sales
FROM Orders o
INNER JOIN Order_Item oi ON o.order_id = oi.order_id
ORDER BY o.order_date;


-- Question 22: Month-over-month change in total profit

WITH Monthly_Profit AS (
    SELECT FORMAT(o.order_date, 'yyyy-MM') AS Order_Month, SUM(oi.profit_per_order) AS Total_Profit
    FROM Orders o
    INNER JOIN Order_Item oi ON o.order_id = oi.order_id
    GROUP BY FORMAT(o.order_date, 'yyyy-MM')
)
SELECT Order_Month, Total_Profit, LAG(Total_Profit) OVER (ORDER BY Order_Month) AS Prev_Month_Profit, Total_Profit - LAG(Total_Profit) OVER (ORDER BY Order_Month) AS MoM_Change
FROM Monthly_Profit
ORDER BY Order_Month;


-- Question 23: Products with stock_quantity below the average stock_quantity of their category

WITH Category_Avg AS (
    SELECT P.category_name, AVG(i.stock_quantity) AS Avg_Stock
    FROM Inventory i
    INNER JOIN Products P ON P.product_id = i.product_id
    GROUP BY P.category_name
)
SELECT P.product_name, P.category_name, i.stock_quantity, ca.Avg_Stock
FROM Inventory i
INNER JOIN Products P ON P.product_id = i.product_id
INNER JOIN Category_Avg ca ON ca.category_name = P.category_name
WHERE i.stock_quantity < ca.Avg_Stock
ORDER BY P.category_name;


-- Question 24: Suppliers whose avg lead_time_days is above the overall average

WITH Overall_Avg AS (
    SELECT AVG(lead_time_days) AS Overall_Lead_Time
    FROM Suppliers
)
SELECT s.supplier_id, s.supplier_name, s.lead_time_days, oa.Overall_Lead_Time
FROM Suppliers s
CROSS JOIN Overall_Avg oa
WHERE s.lead_time_days > oa.Overall_Lead_Time
ORDER BY s.lead_time_days DESC;


-- Question 25: Top 3 highest-selling products per warehouse

SELECT warehouse_location, product_name, Total_Sales, Sales_Rank
FROM (
    SELECT i.warehouse_location, P.product_name, SUM(oi.sales) AS Total_Sales, RANK() OVER (PARTITION BY i.warehouse_location ORDER BY SUM(oi.sales) DESC) AS Sales_Rank
    FROM Inventory i
    INNER JOIN Products P ON P.product_id = i.product_id
    INNER JOIN Order_Item oi ON oi.product_id = i.product_id
    GROUP BY i.warehouse_location, P.product_name
) t
WHERE Sales_Rank <= 3
ORDER BY warehouse_location, Sales_Rank;




