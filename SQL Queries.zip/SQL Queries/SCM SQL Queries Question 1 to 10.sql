Use SCM ;


--Question 1 : List all products with their price, sorted by price descending.

SELECT product_id , product_name , product_price
FROM Products
ORDER BY product_price DESC 



--Question 2 : Find all orders with status = 'Late delivery'.

SELECT * FROM Orders
WHERE delivery_status = 'Late delivery';


--Question 3 : Show all suppliers with rating below 3.

SELECT supplier_id , supplier_name ,rating
FROM Suppliers
WHERE rating < 3;



--Question 4 : Find products currently below their reorder level
SELECT p.product_id, p.product_name ,i.stock_quantity ,i.reorder_level
FROM Products p
inner join Inventory i
ON p.product_id = i.product_id
WHERE i.stock_quantity <i.reorder_level ;


--Question 5 : Count total number of orders per shipping mode.


SELECT shipping_mode ,COUNT(*) AS Cnt 
FROM Orders
GROUP BY shipping_mode
ORDER BY Cnt DESC ;


--Question 6 : Find total sales and profit per product category

SELECT p.category_name ,sum(s.sales) as Total_Sales , SUM(s.profit_per_order) as Total_Profit
FROM  Products p
inner join Order_Item s
ON p.product_id = s.product_id
GROUP BY p.category_name
ORDER BY Total_Sales DESC


--Question 7 : Top 10 customers by total order value.


SELECT TOP 10 c.customer_id , c.first_name  ,sum(oi.item_total) AS Total
FROM Customers C
INNER JOIN Orders o
on o.customer_id= c.customer_id
INNER JOIN Order_Item oi
on o.order_id = oi.order_id
GROUP BY C.customer_id ,c.first_name
ORDER BY Total DESC ;



--Question 8 :Average delivery delay per region.

SELECT 
    order_region,AVG(CASE 
        WHEN days_shipping_actual > days_shipping_scheduled 
        THEN days_shipping_actual - days_shipping_scheduled
        ELSE 0
    END) AS AvgDelay
FROM Orders
GROUP BY order_region
ORDER BY AvgDelay DESC;



--Question 9 : List orders where profit_per_order was negative (loss-making orders)


SELECT Order_ID ,profit_per_order
FROM Order_item
WHERE  profit_per_order <0 ;



--Question 10 : Find total stock quantity held per warehouse.

SELECT warehouse_location , sum(stock_quantity) as Total_Quantity
FROM Inventory
GROUP BY warehouse_location
ORDER BY Total_Quantity DESC ;













